# `@grabm/abm`

Private ESM library for agent simulation. Import `Scenario`, `Simulation`, validation schemas, and codecs from `@grabm/abm`; choose worker execution through `Simulation`, `/analytics` for reports, and `/playback` for Three.js replay.

Three.js and Plotly are optional peers. Node simulation and analytics need neither. `/playback/headless` provides the clock and controls without Three.js. Import `/analytics/plotly` only when using Plotly.

Start with the [first simulation](../../docs/quickstart.md) and [complete import map](../../docs/imports.md). The [developer site](../../docs/index.md) generates reference pages for every public TypeScript entry point.

Optional `/experiments` and `/node` entry points run independent batches. `/datasets` prepares immutable stored runs and reads bounded replay windows through memory, HTTP, or filesystem storage. Backend hosting and authentication remain application-owned.
